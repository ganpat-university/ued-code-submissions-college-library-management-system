function register(){
    let fname = document.getElementById('fName');
    let lname = document.getElementById('lName');
    let email = document.getElementById('email');
    let pass1 = document.getElementById('pass1');
    let pass2 = document.getElementById('pass2');
    let error = document.getElementsByClassName('error');
    let fn=0,ln=0,num=0,alpha1=0,alpha2=0,sb=0,err=0,str='';
    
    if(fname.value.length>3){
        for(let i=0; i<fname.value.length; i++){
            if (!((fname.value[i]>='a' && fname.value[i]<='z')||
                (fname.value[i]>='A' && fname.value[i]<='Z')||
                (fname.value[i]==' '))) {
                fn = 1; //first name contains numbers or symbols
                err=1;
                error[0].innerHTML = "First Name must be in alphabets"
                break;
            }
        }
    }
    else{
        err=1;
        error[0].innerHTML = "First Name must contain atleast 2 alphabets"
    }
    if(lname.value.length>3){
        for(let i=0; i<lname.value.length; i++){
            if (!((lname.value[i]>='a' && lname.value[i]<='z')||
                    (lname.value[i]>='A' && lname.value[i]<='Z')||
                    (lname.value[i]==' '))) {
                ln = 1; //last name contains numbers or symbols
                err=1;
                error[1].innerHTML = "Last Name must be in alphabets"
                break;
            }
        }
    }
    else{
        err=1;
        error[1].innerHTML = "Last Name must contain atleast 2 alphabets"
    }
    if(email.value.indexOf("@gnu.ac.in")==-1){
        err=1;
        error[3].innerHTML = "Use official college email id";
    }
    for(let i=0; i<pass1.value.length; i++){
        if(pass1.value[i]>='0' && pass1.value[i]<='9')
            num=1;
        else if(pass1.value[i]>='a' && pass1.value[i]<='z')
            alpha1=1;
        else if(pass1.value[i]>='A' && pass1.value[i]<='Z')
            alpha2=1;
        else
            sb=1;
    }
    if(num==0){
        err=1;
        str += "Password must contain atleast One Digit";
    }if(alpha2==0){
        err=1;
        if(str.length!=0)
            str+='<br>'
        str += "Password must contain atleast One Capital Alphabet";
    }if(alpha1==0){
        err=1;
        if(str.length!=0)
            str+='<br>'
        str += "Password must contain atleast One Small Alphabet";
    }if(sb==0){
        err=1;
        if(str.length!=0)
            str+='<br>'
        str += "Password must contain atleast One Symbol";
    }
    error[4].innerHTML = str;
    if(pass1.value!=pass2.value){
        err=1;
        error[5].innerHTML = "Password didnot match";
    }
    if(err==0){
    return true;
	}
    return false;
}

function chechLogin(){
    let email = document.getElementById('email');
    let pass1 = document.getElementById('pass1');
    if(email.value.length==0){
        alert('Email must not be empty');
        return false;
    }
    if(pass1.value.length==0){
        alert('Password must not be empty');
        return false;
    }
    return true;
}

function load(){
    let loader = document.getElementById('loading');
    loader.style.display='none';
}

function orderBook(){
    let orderButton = document.getElementById('orderButton');
    orderButton.style.background = "#696969";
    orderButton.style.border='1px solid #696969';
    orderButton.style.cursor='not-allowed';
}

function search(){
    let form = document.getElementById('search');
    let searchBox = document.getElementById('book');
    if(book.value.length == 0){
        alert("Search Box is Empty! Please enter atleast 2 Characters to Search");
        return;
    }
    form.submit();
}

function logout(){
    document.getElementById('logoutUser').submit();
}