package library;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;

@WebServlet(urlPatterns="/contact")
public class contact extends HttpServlet{
	public void doPost(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException {
		String insert; //insert query
		String name=req.getParameter("name");
		String email=req.getParameter("email");
		String subject=req.getParameter("subject");
		String details=req.getParameter("detials");
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/aaryan","root","Aaryan@0210");
			
			insert="INSERT INTO `aaryan`.`contactus`(`name`,`email`,`prob_or_sug`,`details`) VALUES (?, ?, ?, ?);";
			PreparedStatement obj=con.prepareStatement(insert);
			obj.setString(1, name);
			obj.setString(2, email);
			obj.setString(3, subject);
			obj.setString(4, details);
			obj.executeUpdate();
			obj.close();
			con.close();
		}
		catch (Exception e) {}
		RequestDispatcher rd=req.getRequestDispatcher("contact.html");
		rd.forward(req, res);
	}
}