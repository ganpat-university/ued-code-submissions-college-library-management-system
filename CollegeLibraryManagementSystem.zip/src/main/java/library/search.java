package library;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.annotation.WebServlet;

import java.io.IOException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;

@WebServlet(urlPatterns="/search")
public class search extends HttpServlet{
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException,IOException {
		RequestDispatcher rd=req.getRequestDispatcher("searchBook.jsp");
		rd.forward(req, res);
	}
}