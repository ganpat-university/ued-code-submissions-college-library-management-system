package library;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Random;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;

@WebServlet(urlPatterns="/order")
public class order extends HttpServlet{
	public void doPost(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException {
		String insert; //insert query
		Random r=new Random();
		long order_id=100000000+r.nextLong(10000);
		String email=req.getParameter("email");
		int book_id=Integer.parseInt(req.getParameter("book_id"));
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/aaryan","root","Aaryan@0210");
			
			insert="INSERT INTO `aaryan`.`orders`(`order_id`,`email`,`book_id`) VALUES (?, ?, ?);";
			PreparedStatement obj=con.prepareStatement(insert);
			obj.setLong(1, order_id);
			obj.setString(2, email);
			obj.setInt(3, book_id);
			obj.executeUpdate();
			obj.close();
			con.close();
		}
		catch (Exception e) {}
		RequestDispatcher rd=req.getRequestDispatcher(req.getParameter("page"));
		rd.forward(req, res);
	}
}