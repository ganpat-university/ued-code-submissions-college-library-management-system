package library;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet(urlPatterns = "/register")
public class register extends HttpServlet{
	public void doPost(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException {
		String reg; //insert query
		String fname=req.getParameter("firstName");
		String lname=req.getParameter("lastName");
		long num=Long.parseLong(req.getParameter("phone"));
		String email=req.getParameter("email");
		String pw=req.getParameter("pw1");
		PrintWriter p=res.getWriter();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/aaryan","root","Aaryan@0210");
			
			reg="INSERT INTO `aaryan`.`users`(`fname`,`lname`,`phone`,`email`,`password`) VALUES (?, ?, ?, ?, ?);";
			PreparedStatement obj=con.prepareStatement(reg);
			obj.setString(1, fname);
			obj.setString(2, lname);
			obj.setLong(3, num);
			obj.setString(4, email);
			obj.setString(5, pw);
			obj.executeUpdate();
			obj.close();
			con.close();
		}
		catch (Exception e) {
			p.println("Email id is already registered");
			RequestDispatcher rd=req.getRequestDispatcher("register.html");
			rd.forward(req, res);
		}
		RequestDispatcher rd=req.getRequestDispatcher("index.jsp");
		rd.forward(req, res);
	}
}