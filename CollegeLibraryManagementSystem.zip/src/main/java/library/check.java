package library;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet(urlPatterns = "/login")
public class check extends HttpServlet {
	public void doPost(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
		int count=0;  //email 
		String email=req.getParameter("email");
		String pw=req.getParameter("pw");
		PrintWriter p1=res.getWriter();
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/aaryan","root","Aaryan@0210");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from users");

			while(rs.next())
			{
				if(rs.getString("email").equals(email) && rs.getString("password").equals(pw))
				{
					count=1;
					RequestDispatcher rd=req.getRequestDispatcher("index.jsp");
					rd.forward(req, res);
				}
			}	
			if(count==0)
			{
				RequestDispatcher rd=req.getRequestDispatcher("userLogin.html");
				rd.forward(req, res);
			}
		}
		catch(Exception e1){
			p1.println(e1);
		}
	}
}
