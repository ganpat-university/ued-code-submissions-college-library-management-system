package library;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet(urlPatterns = "/admin")
public class admin extends HttpServlet{
	public void doPost(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException{
		int c=1;
		String e=req.getParameter("email");
		String p=req.getParameter("pw");
		PrintWriter p1=res.getWriter();
		try{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/library","root","Aaryan@0210");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from admins");
			
			while(rs.next())
			{
				if(rs.getString("email").equals(e) && rs.getString("pw").equals(p))
				{
					c=0;
					p1.println("Admin Login successful");
				}
			}	
			if(c==1)
			{
				p1.println("Admin Login unsuccessful");
			}
		}
		catch(Exception e1){
			p1.println(e1);
		}
	}
}